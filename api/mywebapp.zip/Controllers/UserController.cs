using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Components;
using Microsoft.AspNetCore.Mvc;
using api.Data;
using api.Mappers;
using api.DTOs.User;

namespace api.Controllers
{
	[Microsoft.AspNetCore.Mvc.Route("api/users")]
	[ApiController]
	public class UserController : ControllerBase
	{
		private readonly ApplicationDBContext _context;

		public UserController(ApplicationDBContext context)
		{
			_context = context;
		}

		[HttpGet("{id}")]
		public IActionResult GetUserById([FromRoute] int id)
		{
			var User = _context.User.Find(id);

			if (User == null)
			{
				return NotFound();
			}
			return Ok(User.ToUserDto());
		}

		[HttpPost]
		public IActionResult PostUser([FromBody] CreateUserRequestDto userDto)
		{
			var userModel = userDto.ToUserFromCreateDto();
			_context.User.Add(userModel);
			_context.SaveChanges();
			return CreatedAtAction(nameof(GetUserById), new {id = userModel.UserId}, userModel.ToUserDto());
		}
	}
}