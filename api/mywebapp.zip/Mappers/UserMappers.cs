using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using api.Models;
using api.DTOs.User;

namespace api.Mappers
{
  public static class UserMappers
{
	public static UserDto ToUserDto(this User userModel)
	{
		return new UserDto
		{
			UserId = userModel.UserId,
			FirstName = userModel.FirstName,
			LastName = userModel.LastName,
			Age = userModel.Age,
			ProfilePicture = userModel.ProfilePicture,
			Weight = userModel.Weight,
			Height = userModel.Height
		};
	}
	public static User ToUserFromCreateDto(this CreateUserRequestDto userDto)
	{
		return new User
		{
			FirstName = userDto.FirstName,
			LastName = userDto.LastName,
			Age = userDto.age,
			ProfilePicture = userDto.ProfilePicture,
			Weight = userDto.Weight,
			Height = userDto.Height
		};
	}
}
}